package main

import (
	"encoding/gob"
	"log"
	"net"
	"os"
	"reflect"
	"time"

	"github.com/michellejns/mint"
)

// ================== Erweiterter PSK-Cache ==================

type FileBackedCache struct {
	*mint.InMemoryPSKCache
	filename string
}

func NewFileBackedCache(filename string) *FileBackedCache {
	return &FileBackedCache{
		InMemoryPSKCache: mint.NewInMemoryPSKCache(),
		filename:         filename,
	}
}

func (f *FileBackedCache) Put(identity string, psk mint.PreSharedKey) {
	log.Printf("📝 [FileBackedCache.Put] Speichere Identity '%x' (gültig bis %v)", identity, psk.ExpiresAt)
	f.InMemoryPSKCache.Put(identity, psk)
	f.save()
}

func (f *FileBackedCache) save() {
	log.Printf("💾 [FileBackedCache.save] Versuche zu speichern: %s", f.filename)
	file, err := os.Create(f.filename)
	if err != nil {
		log.Println("❌ Fehler beim Speichern des PSK-Caches:", err)
		return
	}
	defer file.Close()

	encoder := gob.NewEncoder(file)
	err = encoder.Encode(f.Session)
	if err != nil {
		log.Println("❌ Fehler beim Serialisieren des PSK-Caches:", err)
	} else {
		log.Println("💾 PSK-Cache gespeichert.")
	}
}

func LoadFileBackedCache(filename string) *FileBackedCache {
	f := NewFileBackedCache(filename)
	file, err := os.Open(filename)
	if err != nil {
		log.Println("📂 Kein gespeicherter PSK gefunden.")
		return f
	}
	defer file.Close()

	decoder := gob.NewDecoder(file)
	err = decoder.Decode(&f.Session)
	if err != nil {
		log.Println("❌ Fehler beim Laden des PSK-Caches:", err)
	} else {
		log.Println("📥 PSK-Cache geladen.")
	}
	return f
}

func main() {
	log.Println("+++ PROGRAMM START +++")
	const serverAddr = "localhost:4444"
	const pskFile = "psk_cache.gob"

	cache := LoadFileBackedCache(pskFile)

	conf := &mint.Config{
		ServerName:         "localhost",
		InsecureSkipVerify: true,
		SupportedVersions:  []mint.TLSVersion{mint.TLS13},
		CipherSuites:       mint.DefaultCipherSuites(),
		Enable0RTT:         true,
		AllowEarlyData:     true,
		EarlyDataLifetime:  600,
		PSKs:               cache,
		PSKModes:           []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		SignatureSchemes:   []mint.SignatureScheme{mint.RSA_PKCS1_SHA256},
		Groups:             []mint.NamedGroup{mint.X25519},
		NextProtos:         []string{"h2"},
	}

	// === 1. Voller Handshake zum PSK-Einsammeln ===
	log.Println("+++ 1. Schritt: Handshake starten +++")
	raw1, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal(err)
	}
	c1 := mint.Client(raw1, conf)

	if alert := c1.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("❌ Handshake 1 fehlgeschlagen: %x", alert)
	}
	log.Printf("✅ Handshake 1 erfolgreich – Cachegröße: %d", cache.Size())
	time.Sleep(500 * time.Millisecond)

	// Nach Handshake: Wiederholt lesen, um das NewSessionTicket zu erwischen
	for i := 0; i < 5; i++ {
		buf := make([]byte, 2048)
		n, err := c1.Read(buf)
		log.Printf("[Post-Handshake-Read %d] n=%d, err=%v, Cache.Size=%d", i, n, err, cache.Size())
		if cache.Size() > 0 {
			log.Println("🎉 SessionTicket im Cache!")
			break
		}
		time.Sleep(100 * time.Millisecond)
	}

	raw1.Close()

	// **Anwendungsdaten schicken/lesen, damit Mint wirklich im Connected-State bleibt!**
	msg := []byte("Initial hello from client for ticket processing")
	_, err = c1.Write(msg)
	if err != nil {
		log.Printf("Fehler beim Schreiben nach Handshake: %v", err)
	}

	// Mehrfaches Read, um garantiert das Ticket zu ziehen
	foundTicket := false
	timeout := time.Now().Add(3 * time.Second)
	for time.Now().Before(timeout) {
		buf := make([]byte, 2048)
		n, err := c1.Read(buf)
		log.Printf("[Post-Handshake-Read] n=%d, err=%v, Cache.Size=%d", n, err, cache.Size())
		if cache.Size() > 0 {
			log.Printf(">>> SessionTicket erhalten und gespeichert!")
			foundTicket = true
			break
		}
		if err != nil {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	c1.Close()

	if !foundTicket {
		log.Println("⚠️ Kein SessionTicket im Cache nach Post-Handshake-Loop! 0-RTT wird im 2. Connect nicht funktionieren!")
	}

	// === 2. Neue Instanz für 0-RTT-Verbindung ===
	cache = LoadFileBackedCache(pskFile)
	log.Printf("[DEBUG] PSK-Cache Size vor 0-RTT: %d", cache.Size())
	log.Printf("[DEBUG] Session-Keys: %v", reflect.ValueOf(cache.InMemoryPSKCache.Session).MapKeys())

	// === 0-RTT-Handshake ===
	raw2, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal(err)
	}
	c2 := mint.Client(raw2, conf)
	c2.EarlyData = []byte("👋 Hallo vom Client via 0-RTT!")
	log.Println("+++ 0-RTT Daten gesetzt: ", string(c2.EarlyData))

	sentEarly := false

	for identity, psk := range cache.InMemoryPSKCache.Session {
		log.Printf("DEBUG: PSK-Cache Identity '%x' – IsResumption: %v, ExpiresAt: %v", identity, psk.IsResumption, psk.ExpiresAt)
		if psk.IsResumption {
			log.Printf("📦 Verwende PSK mit Identity '%x'", identity)
			if c2.IsEarlyDataAllowed() {
				err := c2.SendEarlyData()
				if err != nil {
					log.Printf("❌ Fehler beim Senden der 0-RTT-Daten: %v", err)
				} else {
					log.Println("✅ 0-RTT-Daten gesendet.")
					sentEarly = true
				}
			} else {
				log.Println("⚠️ 0-RTT nicht erlaubt – Handshake nicht bereit oder Server erlaubt es nicht.")
			}
			break
		}
	}

	if !sentEarly {
		log.Println("⚠️ Kein PSK verwendet – 0-RTT wird übersprungen")
	}

	// Handshake
	if alert := c2.Handshake(); alert != mint.AlertNoAlert {
		log.Fatalf("❌ Handshake 2 fehlgeschlagen: %x", alert)
	}
	log.Println("✅ Handshake 2 abgeschlossen (mit/ohne 0-RTT)")

	// Schreibe/lese weitere Daten
	msg2 := []byte("hello after 0-RTT connect")
	_, err = c2.Write(msg2)
	if err != nil {
		log.Printf("Fehler beim Schreiben nach 0-RTT-Handshake: %v", err)
	}
	buf2 := make([]byte, 1024)
	n2, err := c2.Read(buf2)
	if err != nil {
		log.Printf("Fehler beim Lesen nach 0-RTT-Handshake: %v", err)
	} else {
		log.Println("Antwort vom Server:", string(buf2[:n2]))
	}
	c2.Close()
}
