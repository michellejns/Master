package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"
	"log"
	"math/big"
	"net"
	"time"

	"github.com/michellejns/mint"
)

func newSelfSigned(name string, alg mint.SignatureScheme, priv crypto.Signer) (*x509.Certificate, error) {
	fmt.Println("🧪 newSelfSigned wurde aufgerufen")
	/*sigAlg, ok := x509AlgMap[alg]
	  if !ok {
	      return nil, fmt.Errorf("tls.selfsigned: Unknown signature algorithm [%04x]", alg)
	  }*/
	if len(name) == 0 {
		return nil, fmt.Errorf("tls.selfsigned: No name provided")
	}

	/*serial, err := rand.Int(rand.Reader, big.NewInt(0xA0A0A0A0))
	  if err != nil {
	      return nil, err
	  }*/

	template := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject: pkix.Name{
			CommonName: "localhost",
		},
		DNSNames:              []string{"localhost"},
		NotBefore:             time.Now(),
		NotAfter:              time.Now().AddDate(0, 0, 1),
		SignatureAlgorithm:    x509.SHA256WithRSA,
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}

	der, err := x509.CreateCertificate(rand.Reader, template, template, priv.Public(), priv)
	if err != nil {
		return nil, err
	}

	// It is safe to ignore the error here because we're parsing known-good data
	cert, err := x509.ParseCertificate(der)
	if err != nil {
		fmt.Printf("Fehler beim Parsen des Zertifikats: %v", err)
		return nil, err
	}

	fmt.Printf("📛 DNSNames im geparsten Zertifikat: %v", cert.DNSNames)
	return cert, nil

}

func main() {

	// 1. Generiere Schlüsselpaar
	priv, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		log.Fatal("Fehler beim Erzeugen des privaten Schlüssels:", err)
	}

	// 2. Erstelle Self-Signed-Zertifikat
	cert, err := newSelfSigned("localhost", mint.RSA_PKCS1_SHA256, priv) // Aufruf der Funktion
	if err != nil {
		log.Fatal("Fehler beim Erstellen des Zertifikats:", err)
	}

	// 3. Baue Mint-Konfiguration
	conf := &mint.Config{
		ServerName: "localhost",

		Certificates: []*mint.Certificate{
			{
				Chain:      []*x509.Certificate{cert},
				PrivateKey: priv,
			},
		},

		SupportedVersions: []mint.TLSVersion{mint.TLS13},
		CipherSuites:      mint.DefaultCipherSuites(),

		RequireClientAuth:   false,
		RequireCookie:       false,
		AllowInsecureHashes: true,
		Enable0RTT:          true, // erstmal sicher deaktivieren
		SendSessionTickets:  true, // aktiviert die automatische Erzeugung und das Verschicken von NewSessionTicket-Nachrichten
		AllowEarlyData:      true,
		TicketLen:           32, // Länge des Session-tickets muss > 0 sein, das bestimmt wieviele zufallsbytes für das ticket
		// also quasi die nonce, erstellt werden
		EarlyDataLifetime: 10 * 60, // 10 Minuten gültig
		TicketLifetime:    10 * 60, // 10 Minuten gültig
		PSKModes:          []mint.PSKKeyExchangeMode{mint.PSKModeDHEKE},
		PSKs:              mint.NewInMemoryPSKCache(),
		SignatureSchemes: []mint.SignatureScheme{
			mint.RSA_PKCS1_SHA256, // <-- Muss zum Cert passen
		},
		Groups: []mint.NamedGroup{
			mint.X25519,
		},
		NextProtos: []string{"h2"},
	}

	// 4. Starte TCP-Listener
	ln, err := net.Listen("tcp", ":4444")
	if err != nil {
		log.Fatal(err)
	}
	log.Println("Server wartet auf Verbindungen...")

	log.Printf("📜 TLS-Konfiguration: %+v\n", conf)

	// 5. Akzeptiere Verbindungen und starte TLS
	for {
		rawConn, err := ln.Accept()
		if err != nil {
			log.Fatal(err)
		}

		conn := mint.Server(rawConn, conf)
		alert := conn.Handshake()
		if alert == mint.AlertNoAlert {
			log.Println("✅ Handshake erfolgreich")
			time.Sleep(2 * time.Second)

			// EARLY DATA LESEN, SOFERN AKTIV
			if conn.UsingEarlyData {
				log.Println("🚀 Server: Lese explizit Early Data ...")
				for i := 0; i < 3; i++ {
					buf := make([]byte, 1024)
					n, err := conn.Read(buf)
					time.Sleep(2 * time.Second)
					if err != nil {
						log.Printf("Fehler beim Lesen von Early Data: %v", err)
					} else if n > 0 {
						log.Printf("🌟 Early Data empfangen: %s", string(buf[:n]))
					} else {
						log.Println("Kein Early Data empfangen!")
					}
				}
			}
			// Optional: weitere Reads für "normale" Daten nach Handshake
			buf := make([]byte, 1024)
			n, err := conn.Read(buf)
			time.Sleep(2 * time.Second)
			if err != nil {
				log.Println("Fehler beim Lesen:", err)
				continue
			}
			log.Println("Nachricht empfangen:", string(buf[:n]))
		} else {
			log.Printf("❌ Handshake fehlgeschlagen: 0x%x\n", alert)
			continue
		}

		// 6. Lese Daten vom Client
		buf := make([]byte, 1024)
		n, err := conn.Read(buf)
		time.Sleep(2 * time.Second)
		if err != nil {
			log.Println("Fehler beim Lesen:", err)
			continue
		}
		log.Println("Nachricht empfangen:", string(buf[:n]))
	}
}
